import { Task, TaskStatus, WorkLog, UserRole, BoundingBox } from '../types';
import JSZip from 'jszip';

const TASKS_KEY = 'yolo_tasks';
const LOGS_KEY = 'yolo_logs';

// --- YOLO Format Helper Functions ---

export const parseYoloTxt = (content: string): BoundingBox[] => {
  if (!content) return [];

  return content.split('\n')
    .map(line => line.trim())
    .filter(line => line.length > 0)
    .map(line => {
      const parts = line.split(' ');
      if (parts.length < 5) return null;

      const classId = parseInt(parts[0], 10);
      const cx = parseFloat(parts[1]);
      const cy = parseFloat(parts[2]);
      const w = parseFloat(parts[3]);
      const h = parseFloat(parts[4]);

      const x = cx - (w / 2);
      const y = cy - (h / 2);

      return {
        id: Math.random().toString(36).substr(2, 9),
        classId,
        x,
        y,
        w,
        h,
        isAutoLabel: false
      } as BoundingBox;
    })
    .filter((box): box is BoundingBox => box !== null);
};

export const generateYoloTxt = (annotations: BoundingBox[]): string => {
  return annotations.map(ann => {
    const cx = ann.x + (ann.w / 2);
    const cy = ann.y + (ann.h / 2);
    return `${ann.classId} ${cx.toFixed(6)} ${cy.toFixed(6)} ${ann.w.toFixed(6)} ${ann.h.toFixed(6)}`;
  }).join('\n');
};

// --- Storage Logic ---

// In-memory cache
let cachedFolders: any[] = [];
let cachedTasks: Task[] = [];
let isInitialized = false;

// 1. Initialize: Fetch all image data from server
export const initStorage = async () => {
  try {
    const res = await fetch('/api/datasets');
    if (!res.ok) throw new Error('Failed to fetch datasets');
    const files = await res.json();

    const stored = localStorage.getItem(TASKS_KEY);
    const existingTasks: Task[] = stored ? JSON.parse(stored) : [];

    // Efficiently merge using a Map (O(N)) - Use ID for uniqueness
    const taskMap = new Map(existingTasks.map(t => [t.id, t]));

    cachedTasks = files.map((f: any) => {
      const existing = taskMap.get(f.id);
      if (existing) {
        return {
          ...f,
          status: existing.status,
          isModified: existing.isModified,
          annotations: existing.annotations || f.annotations || [],
          reviewerNotes: existing.reviewerNotes,
          assignedWorker: existing.assignedWorker || f.assignedWorker,
          lastUpdated: Math.max(f.lastUpdated || 0, existing.lastUpdated || 0)
        };
      }
      return f;
    });

    // Strip annotations before saving to localStorage to save space
    const tasksToStore = cachedTasks.map(({ annotations, ...rest }) => rest);
    localStorage.setItem(TASKS_KEY, JSON.stringify(tasksToStore));
    isInitialized = true;
  } catch (e) {
    console.error("Storage Init Failed:", e);
  }
};

export const getTasks = (): Task[] => {
  return cachedTasks;
};

export const getTaskById = async (id: string): Promise<Task | undefined> => {
  const task = cachedTasks.find(t => t.id === id);
  if (!task) return undefined;

  // If annotations are still empty, try to load from labels
  if ((!task.annotations || task.annotations.length === 0) && task.txtPath) {
    try {
      const res = await fetch(`/api/label?path=${encodeURIComponent(task.txtPath)}`);
      const text = await res.text();
      if (text) {
        task.annotations = parseYoloTxt(text);
        updateTaskInCache(task);
      }
    } catch (e) {
      console.error("Failed to load labels for task", task.id, e);
    }
  }
  return task;
};

const updateTaskInCache = (task: Task) => {
  const index = cachedTasks.findIndex(t => t.id === task.id);
  if (index !== -1) {
    cachedTasks[index] = task;

    // Persist to localStorage WITHOUT annotations
    const stored = localStorage.getItem(TASKS_KEY);
    if (stored) {
      const existingTasks: any[] = JSON.parse(stored);
      const storageIndex = existingTasks.findIndex(t => t.id === task.id);
      if (storageIndex !== -1) {
        const { annotations, ...taskWithoutAnnotations } = task;
        existingTasks[storageIndex] = taskWithoutAnnotations;
        localStorage.setItem(TASKS_KEY, JSON.stringify(existingTasks));
      }
    }
  }
}

export const updateTask = async (taskId: string, updates: Partial<Task>, userId: string, role: UserRole): Promise<Task> => {
  const task = cachedTasks.find(t => t.id === taskId);
  if (!task) throw new Error('Task not found');

  const updatedTask = { ...task, ...updates, lastUpdated: Date.now() };

  // 1. Update In-Memory & LocalStorage (for fast UI)
  updateTaskInCache(updatedTask);

  // 2. Persist to Disk if annotations changed or status submitted
  if (updates.annotations || updates.status === TaskStatus.SUBMITTED) {
    if (!updatedTask.txtPath) {
      // We need to determine the save path if it wasn't scanned initially.
      // It should be adjacent to the image.
      // Since we don't have the absolute path easily for new files, 
      // we can rely on the server to handle this if we send the image path?
      // OR: We know the structure is datasets/[folder]/[image].
      // The API list gave us 'txtPath' if it existed.
      // If it didn't exist, we must construct it.

      // Hack: Construct relative txt path based on image url
      // imageUrl: /datasets/folder/image.jpg
      // expected txt: datasets/folder/image.txt
      // The imageUrl in vite starts with /, so remove it

      let relativeTxtPath = updatedTask.imageUrl.startsWith('/') ? updatedTask.imageUrl.substring(1) : updatedTask.imageUrl;
      relativeTxtPath = relativeTxtPath.substring(0, relativeTxtPath.lastIndexOf('.')) + '.txt';
      updatedTask.txtPath = relativeTxtPath;
    }

    const content = generateYoloTxt(updatedTask.annotations);

    try {
      await fetch('/api/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          path: updatedTask.txtPath,
          content: content
        })
      });
    } catch (e) {
      console.error("Failed to save to disk", e);
      alert("Failed to save to disk! Check console.");
    }
  }


  // 3. Persist Metadata (status, isModified, assignedWorker, reviewerNotes)
  // We save this to _metadata.json via /api/metadata
  if (updates.status || updates.isModified !== undefined || updates.assignedWorker !== undefined || updates.reviewerNotes !== undefined) {
    try {
      // Use relative path from datasets root as key.
      // imageUrl looks like /datasets/worker1/folderA/image.jpg
      const key = updatedTask.imageUrl.startsWith('/datasets/')
        ? updatedTask.imageUrl.substring('/datasets/'.length)
        : (updatedTask.folder === 'Unsorted' ? updatedTask.name : `${updatedTask.folder}/${updatedTask.name}`);

      await fetch('/api/metadata', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          key,
          updates: {
            status: updatedTask.status,
            isModified: updatedTask.isModified,
            assignedWorker: updatedTask.assignedWorker,
            reviewerNotes: updatedTask.reviewerNotes,
            lastUpdated: updatedTask.lastUpdated
          }
        })
      });
    } catch (e) {
      console.error("Failed to save metadata", e);
    }
  }

  return updatedTask;
};

export const assignFolderToWorker = async (folderName: string, workerName: string | undefined) => {
  // 1. Update Local Cache (Optimistic UI)
  const timestamp = Date.now();
  // Update In-Memory Cache
  cachedTasks = cachedTasks.map(t => {
    if (t.folder === folderName) {
      return { ...t, assignedWorker: workerName, lastUpdated: timestamp };
    }
    return t;
  });

  // Update LocalStorage WITHOUT annotations
  const stored = localStorage.getItem(TASKS_KEY);
  if (stored) {
    const existingTasks: any[] = JSON.parse(stored);
    const updatedTasks = existingTasks.map(t => {
      if (t.folder === folderName) {
        return { ...t, assignedWorker: workerName, lastUpdated: timestamp };
      }
      return t;
    });
    localStorage.setItem(TASKS_KEY, JSON.stringify(updatedTasks));
  }

  // 2. Persist to Server (Physical Move)
  try {
    await fetch('/api/assign-worker', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        folderName,
        workerName: workerName || 'Unassigned'
      })
    });

    // Also sync the redundant folder-metadata for backup/tags
    await fetch('/api/folder-metadata', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        folder: folderName,
        updates: { assignedWorker: workerName, lastUpdated: timestamp }
      })
    });
  } catch (e) {
    console.error("Failed to sync physical folder assignment", e);
  }
};

export const logAction = (
  taskId: string,
  userId: string,
  role: UserRole,
  action: WorkLog['action'],
  durationSeconds: number = 0
) => {
  const logs: WorkLog[] = JSON.parse(localStorage.getItem(LOGS_KEY) || '[]');

  const task = cachedTasks.find(t => t.id === taskId);
  let stats = undefined;
  if (task && (action === 'SUBMIT' || action === 'APPROVE' || action === 'SAVE')) {
    stats = {
      totalBoxCount: task.annotations.length,
      manualBoxCount: task.annotations.filter(a => !a.isAutoLabel).length
    };
  }

  const newLog: WorkLog = {
    id: Math.random().toString(36).substr(2, 9),
    taskId,
    userId,
    role,
    folder: task?.folder || 'Unknown',
    action,
    timestamp: Date.now(),
    durationSeconds,
    isModified: task?.isModified,
    stats
  };
  logs.push(newLog);
  localStorage.setItem(LOGS_KEY, JSON.stringify(logs));
};

export const getLogs = (): WorkLog[] => {
  return JSON.parse(localStorage.getItem(LOGS_KEY) || '[]');
};

export const getFolderMetadata = (folderName: string): any => {
  const allMeta = JSON.parse(localStorage.getItem('yolo_folder_meta') || '{}');
  const meta = allMeta[folderName] || {};
  return {
    tags: [],
    memo: '',
    ...meta
  };
};

export const saveFolderMetadata = async (folderName: string, meta: any) => {
  const allMeta = JSON.parse(localStorage.getItem('yolo_folder_meta') || '{}');
  allMeta[folderName] = meta;
  localStorage.setItem('yolo_folder_meta', JSON.stringify(allMeta));

  // Sync to Server
  try {
    await fetch('/api/folder-metadata', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        folder: folderName,
        updates: meta
      })
    });
  } catch (e) {
    console.error("Failed to sync folder metadata to server", e);
  }
};

export const convertFolderToWebp = async (folderName: string, limit?: number, offset?: number) => {
  try {
    const res = await fetch('/api/convert-folder', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ folderName, limit, offset })
    });
    if (!res.ok) return null;
    return await res.json();
  } catch (e) {
    console.error("Batch conversion trigger failed", e);
    return null;
  }
};

export const getAllFolderMetadata = (): Record<string, any> => {
  return JSON.parse(localStorage.getItem('yolo_folder_meta') || '{}');
};

export const downloadFullDataset = async () => {
  const zip = new JSZip();
  const tasks = getTasks();

  // 1. Add Annotations (.txt) organized by folder
  // Note: Since we are now saving to disk, downloading zip might just serve the files.
  // But for convenience of "Export", we still zip them up from memory/cache or fetch them.
  // Here we use the latest memory state (which should match disk).

  tasks.forEach(task => {
    if (task.annotations.length > 0) {
      const txtContent = generateYoloTxt(task.annotations);
      const baseName = task.name.substring(0, task.name.lastIndexOf('.'));
      zip.file(`${task.folder}/${baseName}.txt`, txtContent);
    }
  });

  const blob = await zip.generateAsync({ type: 'blob' });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `yolo_dataset_export_${new Date().toISOString().slice(0, 10)}.zip`;
  a.click();
  window.URL.revokeObjectURL(url);
};