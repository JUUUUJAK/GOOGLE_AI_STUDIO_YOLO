import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import fs from 'fs';
import path from 'path';
import sharp from 'sharp';
import crypto from 'crypto';

// Middleware to handle file system operations
const fileSystemMiddleware = () => ({
  name: 'file-system-middleware',
  configureServer(server) {
    server.middlewares.use(async (req, res, next) => {
      if (req.url.startsWith('/api/datasets')) {
        // GET /api/datasets: Recursively scan 'datasets' folder
        try {
          const datasetsDir = path.resolve(__dirname, 'datasets');
          if (!fs.existsSync(datasetsDir)) {
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify([]));
            return;
          }

          const metadataPath = path.join(datasetsDir, '_metadata.json');
          const folderMetaPath = path.join(datasetsDir, '_folder_metadata.json');
          let metadata = {};
          let folderMetadata = {};

          if (fs.existsSync(metadataPath)) {
            try { metadata = JSON.parse(fs.readFileSync(metadataPath, 'utf-8')); } catch (e) { }
          }
          if (fs.existsSync(folderMetaPath)) {
            try { folderMetadata = JSON.parse(fs.readFileSync(folderMetaPath, 'utf-8')); } catch (e) { }
          }

          const usersPath = path.resolve(__dirname, 'users.json');
          let validWorkers = [];
          if (fs.existsSync(usersPath)) {
            try {
              validWorkers = JSON.parse(fs.readFileSync(usersPath, 'utf-8'))
                .filter(u => u.accountType === 'WORKER')
                .map(u => u.username);
            } catch (e) { }
          }

          const getFiles = (dir, currentWorker = undefined) => {
            let results = [];
            const list = fs.readdirSync(dir);
            list.forEach(file => {
              const filePath = path.join(dir, file);
              const stat = fs.statSync(filePath);

              if (stat && stat.isDirectory()) {
                let nextWorker = currentWorker;
                if (!currentWorker && dir === datasetsDir && validWorkers.includes(file)) {
                  nextWorker = file;
                }
                results = results.concat(getFiles(filePath, nextWorker));
              } else {
                if (/\.(jpg|jpeg|png|webp|bmp)$/i.test(file)) {
                  const ext = path.extname(file);
                  const baseName = path.basename(file, ext);
                  const txtPath = path.join(dir, baseName + '.txt');
                  const relativePath = path.relative(path.resolve(__dirname), filePath).replace(/\\/g, '/');
                  const metaKey = path.relative(datasetsDir, filePath).replace(/\\/g, '/');
                  const fileMeta = metadata[metaKey] || {};

                  // Determine folder name
                  let folderName = 'Unsorted';
                  if (currentWorker) {
                    const workerDir = path.join(datasetsDir, currentWorker);
                    folderName = path.relative(workerDir, dir).replace(/\\/g, '/') || 'Unsorted';
                  } else {
                    folderName = path.relative(datasetsDir, dir).replace(/\\/g, '/') || 'Unsorted';
                  }

                  results.push({
                    id: crypto.createHash('md5').update(relativePath).digest('hex'),
                    name: file,
                    folder: folderName,
                    imageUrl: '/' + relativePath,
                    txtPath: fs.existsSync(txtPath) ? path.relative(path.resolve(__dirname), txtPath).replace(/\\/g, '/') : null,
                    assignedWorker: currentWorker || fileMeta.assignedWorker,
                    status: fileMeta.status || 'TODO',
                    annotations: [], // Placeholder, will be loaded on demand or was previously
                    isModified: !!fileMeta.isModified,
                    reviewerNotes: fileMeta.reviewerNotes || '',
                    lastUpdated: fileMeta.lastUpdated
                  });
                }
              }
            });
            return results;
          }

          const files = getFiles(datasetsDir);
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify(files));
        } catch (e) {
          console.error(e);
          res.statusCode = 500;
          res.end(JSON.stringify({ error: e.message }));
        }
      } else if (req.url.startsWith('/api/metadata') && req.method === 'POST') {
        // POST /api/metadata (Body: { key: string, updates: any })
        let body = '';
        req.on('data', chunk => {
          body += chunk.toString();
        });
        req.on('end', () => {
          try {
            const datasetsDir = path.resolve(__dirname, 'datasets');
            if (!fs.existsSync(datasetsDir)) fs.mkdirSync(datasetsDir);
            const metadataPath = path.join(datasetsDir, '_metadata.json');

            let metadata = {};
            if (fs.existsSync(metadataPath)) {
              try { metadata = JSON.parse(fs.readFileSync(metadataPath, 'utf-8')); } catch (e) { }
            }

            const data = JSON.parse(body);

            if (data.batch && Array.isArray(data.batch)) {
              // Batch Update
              data.batch.forEach((item: any) => {
                const { key, updates } = item;
                if (key && updates) {
                  metadata[key] = { ...(metadata[key] || {}), ...updates };
                }
              });
            } else {
              // Single Update
              const { key, updates } = data;
              if (key && updates) {
                metadata[key] = { ...(metadata[key] || {}), ...updates };
              }
            }

            fs.writeFileSync(metadataPath, JSON.stringify(metadata, null, 2), 'utf-8');

            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify({ success: true }));
          } catch (e) {
            console.error(e);
            res.statusCode = 500;
            res.end(JSON.stringify({ error: e.message }));
          }
        });
      } else if (req.url.startsWith('/api/folder-metadata')) {
        if (req.method === 'GET') {
          try {
            const datasetsDir = path.resolve(__dirname, 'datasets');
            const metaPath = path.join(datasetsDir, '_folder_metadata.json');
            let data = {};
            if (fs.existsSync(metaPath)) {
              data = JSON.parse(fs.readFileSync(metaPath, 'utf-8'));
            }
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify(data));
          } catch (e) {
            res.statusCode = 500;
            res.end(JSON.stringify({ error: e.message }));
          }
        } else if (req.method === 'POST') {
          let body = '';
          req.on('data', chunk => { body += chunk.toString(); });
          req.on('end', () => {
            try {
              const datasetsDir = path.resolve(__dirname, 'datasets');
              if (!fs.existsSync(datasetsDir)) fs.mkdirSync(datasetsDir);
              const metaPath = path.join(datasetsDir, '_folder_metadata.json');
              let metadata = {};
              if (fs.existsSync(metaPath)) {
                try { metadata = JSON.parse(fs.readFileSync(metaPath, 'utf-8')); } catch (e) { }
              }
              const { folder, updates } = JSON.parse(body);
              if (folder && updates) {
                metadata[folder] = { ...(metadata[folder] || {}), ...updates };
                fs.writeFileSync(metaPath, JSON.stringify(metadata, null, 2), 'utf-8');
              }
              res.setHeader('Content-Type', 'application/json');
              res.end(JSON.stringify({ success: true }));
            } catch (e) {
              res.statusCode = 500;
              res.end(JSON.stringify({ error: e.message }));
            }
          });
        }
      } else if (req.url.startsWith('/api/label-files')) {
        // GET /api/label-files: List .txt files in 'labels' folder
        try {
          const labelsDir = path.resolve(__dirname, 'labels');
          if (!fs.existsSync(labelsDir)) {
            fs.mkdirSync(labelsDir);
          }
          const files = fs.readdirSync(labelsDir).filter(f => f.endsWith('.txt'));
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify(files));
        } catch (e) {
          res.statusCode = 500;
          res.end(JSON.stringify({ error: e.message }));
        }
      } else if (req.url.startsWith('/api/label') && req.method === 'GET') {
        // GET /api/label?path=...
        try {
          const url = new URL(req.url, `http://${req.headers.host}`);
          const labelPath = url.searchParams.get('path');
          if (!labelPath) throw new Error('Path required');

          const fullPath = path.resolve(__dirname, labelPath);
          if (fs.existsSync(fullPath)) {
            const content = fs.readFileSync(fullPath, 'utf-8');
            res.setHeader('Content-Type', 'text/plain');
            res.end(content);
          } else {
            res.setHeader('Content-Type', 'text/plain');
            res.end('');
          }
        } catch (e) {
          res.statusCode = 500;
          res.end(e.message);
        }
      } else if (req.url.startsWith('/api/assign-worker') && req.method === 'POST') {
        // POST /api/assign-worker (Body: { folderName: string, workerName: string | undefined })
        let body = '';
        req.on('data', chunk => { body += chunk.toString(); });
        req.on('end', async () => {
          try {
            const { folderName, workerName } = JSON.parse(body);
            const datasetsDir = path.resolve(__dirname, 'datasets');

            // 1. Find Current Location
            // We need to look in datasets root AND in every worker folder
            let sourcePath = path.join(datasetsDir, folderName);
            if (!fs.existsSync(sourcePath)) {
              // Check in worker subfolders
              const workers = fs.readdirSync(datasetsDir).filter(f => fs.statSync(path.join(datasetsDir, f)).isDirectory());
              for (const w of workers) {
                const p = path.join(datasetsDir, w, folderName);
                if (fs.existsSync(p)) {
                  sourcePath = p;
                  break;
                }
              }
            }

            if (!fs.existsSync(sourcePath)) {
              res.statusCode = 404;
              res.end(JSON.stringify({ error: 'Folder not found' }));
              return;
            }

            // 2. Determine Target Location
            let targetPath;
            if (!workerName || workerName === 'Unassigned') {
              targetPath = path.join(datasetsDir, folderName);
            } else {
              targetPath = path.join(datasetsDir, workerName, folderName);
              if (!fs.existsSync(path.join(datasetsDir, workerName))) {
                fs.mkdirSync(path.join(datasetsDir, workerName), { recursive: true });
              }
            }

            // 3. Move
            if (sourcePath !== targetPath) {
              if (fs.existsSync(targetPath)) {
                // Handle collision? For now just overwrite or error
                res.statusCode = 409;
                res.end(JSON.stringify({ error: 'Target folder already exists' }));
                return;
              }
              fs.renameSync(sourcePath, targetPath);
            }

            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify({ success: true }));
          } catch (e) {
            console.error(e);
            res.statusCode = 500;
            res.end(JSON.stringify({ error: e.message }));
          }
        });
      } else if (req.url.startsWith('/api/save') && req.method === 'POST') {
        // POST /api/save (Body: { path: string, content: string })
        let body = '';
        req.on('data', chunk => {
          body += chunk.toString();
        });
        req.on('end', () => {
          try {
            const data = JSON.parse(body);
            const fullPath = path.resolve(__dirname, data.path);

            // Ensure directory exists (optional, but safe)
            // fs.mkdirSync(path.dirname(fullPath), { recursive: true });

            fs.writeFileSync(fullPath, data.content, 'utf-8');
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify({ success: true }));
          } catch (e) {
            console.error(e);
            res.statusCode = 500;
            res.end(JSON.stringify({ error: e.message }));
          }
        });
      } else if (req.url.startsWith('/api/users')) {
        const usersPath = path.resolve(__dirname, 'users.json');

        if (req.method === 'GET') {
          try {
            if (fs.existsSync(usersPath)) {
              const users = JSON.parse(fs.readFileSync(usersPath, 'utf-8'));
              res.setHeader('Content-Type', 'application/json');
              res.end(JSON.stringify(users));
            } else {
              res.setHeader('Content-Type', 'application/json');
              res.end(JSON.stringify([]));
            }
          } catch (e) {
            res.statusCode = 500;
            res.end(JSON.stringify({ error: e.message }));
          }
        } else if (req.method === 'POST') {
          let body = '';
          req.on('data', chunk => { body += chunk.toString(); });
          req.on('end', () => {
            try {
              const data = JSON.parse(body);
              let users = [];
              if (fs.existsSync(usersPath)) {
                users = JSON.parse(fs.readFileSync(usersPath, 'utf-8'));
              }

              // Check if update or create
              // If only username and password provided (and maybe accountType), check if exists
              const existingUserIndex = users.findIndex(u => u.username === data.username);

              if (existingUserIndex >= 0) {
                // Update existing user (e.g. password)
                // In a real app we would hash the password. here we just store plain text for now as per plan
                users[existingUserIndex].password = data.password;
                if (data.accountType) users[existingUserIndex].accountType = data.accountType;
              } else {
                // Create new user
                users.push({
                  username: data.username,
                  password: data.password, // Storing plain text as requested/planned due to no bcrypt
                  accountType: data.accountType || 'WORKER'
                });
              }

              fs.writeFileSync(usersPath, JSON.stringify(users, null, 2), 'utf-8');
              res.setHeader('Content-Type', 'application/json');
              res.end(JSON.stringify({ success: true }));
            } catch (e) {
              res.statusCode = 500;
              res.end(JSON.stringify({ error: e.message }));
            }
          });
        }
      } else if (req.url.startsWith('/api/groups')) {
        const groupsPath = path.resolve(__dirname, 'datasets', '_groups.json');

        if (req.method === 'GET') {
          try {
            if (fs.existsSync(groupsPath)) {
              const content = fs.readFileSync(groupsPath, 'utf-8');
              res.setHeader('Content-Type', 'application/json');
              res.end(content);
            } else {
              res.setHeader('Content-Type', 'application/json');
              res.end(JSON.stringify({}));
            }
          } catch (e) {
            res.statusCode = 500;
            res.end(JSON.stringify({ error: e.message }));
          }
        } else if (req.method === 'POST') {
          let body = '';
          req.on('data', chunk => { body += chunk.toString(); });
          req.on('end', () => {
            try {
              const { folder, groupName } = JSON.parse(body);
              let groups = {};
              if (fs.existsSync(groupsPath)) {
                groups = JSON.parse(fs.readFileSync(groupsPath, 'utf-8'));
              }

              if (folder) {
                groups[folder] = { group: groupName };
                fs.writeFileSync(groupsPath, JSON.stringify(groups, null, 2), 'utf-8');
              }

              res.setHeader('Content-Type', 'application/json');
              res.end(JSON.stringify({ success: true }));
            } catch (e) {
              res.statusCode = 500;
              res.end(JSON.stringify({ error: e.message }));
            }
          });
        }
      } else if (req.url.startsWith('/api/convert-folder') && req.method === 'POST') {
        let body = '';
        req.on('data', chunk => { body += chunk.toString(); });
        req.on('end', async () => {
          try {
            const { folderName, limit, offset } = JSON.parse(body);
            const datasetsDir = path.resolve(__dirname, 'datasets');
            const cacheDir = path.join(datasetsDir, '.cache');
            if (!fs.existsSync(cacheDir)) fs.mkdirSync(cacheDir, { recursive: true });

            // 1. Find Folder
            let targetFolder = path.join(datasetsDir, folderName);
            if (!fs.existsSync(targetFolder)) {
              const workers = fs.readdirSync(datasetsDir).filter(f => fs.statSync(path.join(datasetsDir, f)).isDirectory());
              for (const w of workers) {
                const p = path.join(datasetsDir, w, folderName);
                if (fs.existsSync(p)) {
                  targetFolder = p;
                  break;
                }
              }
            }

            if (!fs.existsSync(targetFolder)) {
              res.statusCode = 404;
              res.end(JSON.stringify({ error: 'Folder not found' }));
              return;
            }

            // 2. Scan for Images
            const getImagesByDir = (dir: string): string[] => {
              let results: string[] = [];
              const list = fs.readdirSync(dir);
              list.forEach(file => {
                const filePath = path.join(dir, file);
                const stat = fs.statSync(filePath);
                if (stat && stat.isDirectory()) {
                  results = results.concat(getImagesByDir(filePath));
                } else if (/\.(jpg|jpeg|png|bmp)$/i.test(file)) {
                  results.push(filePath);
                }
              });
              return results;
            }
            const allImages = getImagesByDir(targetFolder);

            // Apply Limit & Offset
            const start = offset || 0;
            const end = limit ? start + limit : allImages.length;
            const images = allImages.slice(start, end);

            // 3. Batch Convert (with parallel limit to avoid crashing)
            const concurrency = 5;
            for (let i = 0; i < images.length; i += concurrency) {
              const chunk = images.slice(i, i + concurrency);
              await Promise.all(chunk.map(async (filePath) => {
                const relativeToDatasets = path.relative(datasetsDir, filePath).replace(/\\/g, '/');
                const cacheKey = crypto.createHash('md5').update(relativeToDatasets).digest('hex') + '.webp';
                const cachePath = path.join(cacheDir, cacheKey);

                if (!fs.existsSync(cachePath)) {
                  try {
                    await sharp(filePath).webp({ quality: 80 }).toFile(cachePath);
                  } catch (e) {
                    console.error(`Conversion failed for ${filePath}:`, e);
                  }
                }
              }));
            }

            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify({
              success: true,
              count: images.length,
              total: allImages.length,
              offset: start,
              limit: limit
            }));
          } catch (e) {
            console.error(e);
            res.statusCode = 500;
            res.end(JSON.stringify({ error: e.message }));
          }
        });
      } else if (req.url.startsWith('/api/login') && req.method === 'POST') {
        let body = '';
        req.on('data', chunk => { body += chunk.toString(); });
        req.on('end', () => {
          try {
            const { username, password } = JSON.parse(body);
            const usersPath = path.resolve(__dirname, 'users.json');

            if (!fs.existsSync(usersPath)) {
              res.statusCode = 401;
              res.end(JSON.stringify({ error: 'Invalid credentials' }));
              return;
            }

            const users = JSON.parse(fs.readFileSync(usersPath, 'utf-8'));
            const user = users.find(u => u.username === username && u.password === password);

            if (user) {
              res.setHeader('Content-Type', 'application/json');
              res.end(JSON.stringify({
                username: user.username,
                accountType: user.accountType,
                token: 'mock-token-' + Date.now()
              }));
            } else {
              res.statusCode = 401;
              res.end(JSON.stringify({ error: 'Invalid credentials' }));
            }
          } catch (e) {
            res.statusCode = 500;
            res.end(JSON.stringify({ error: e.message }));
          }
        });
      } else if (req.url.startsWith('/datasets')) {
        // Manual static file serving with WebP optimization
        try {
          const urlObj = new URL(req.url, `http://${req.headers.host}`);
          const decodedPath = decodeURIComponent(urlObj.pathname);
          const filePath = path.join(__dirname, decodedPath.startsWith('/') ? decodedPath.slice(1) : decodedPath);

          if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
            const ext = path.extname(filePath).toLowerCase();
            const isImage = /\.(jpg|jpeg|png|webp|bmp)$/i.test(ext);

            if (isImage) {
              const datasetsDir = path.resolve(__dirname, 'datasets');
              const cacheDir = path.join(datasetsDir, '.cache');
              if (!fs.existsSync(cacheDir)) fs.mkdirSync(cacheDir, { recursive: true });

              const relativeToDatasets = path.relative(datasetsDir, filePath).replace(/\\/g, '/');
              const cacheKey = crypto.createHash('md5').update(relativeToDatasets).digest('hex') + '.webp';
              const cachePath = path.join(cacheDir, cacheKey);

              // Check Cache
              if (fs.existsSync(cachePath)) {
                res.setHeader('Content-Type', 'image/webp');
                res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
                fs.createReadStream(cachePath).pipe(res);
                return;
              }

              // On-the-fly conversion
              try {
                const buffer = await sharp(filePath)
                  .webp({ quality: 80 })
                  .toBuffer();

                fs.writeFileSync(cachePath, buffer);
                res.setHeader('Content-Type', 'image/webp');
                res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
                res.end(buffer);
                return;
              } catch (err) {
                console.error("WebP conversion failed:", err);
                // Fallback to original
              }
            }

            const mimeTypes: Record<string, string> = {
              '.jpg': 'image/jpeg',
              '.jpeg': 'image/jpeg',
              '.png': 'image/png',
              '.webp': 'image/webp',
              '.bmp': 'image/bmp',
              '.gif': 'image/gif'
            };
            res.setHeader('Content-Type', mimeTypes[ext] || 'application/octet-stream');
            fs.createReadStream(filePath).pipe(res);
          } else {
            next();
          }
        } catch (e) {
          console.error("Static serve error:", e);
          next();
        }
      } else {
        next();
      }
    });
  }
});

export default defineConfig({
  plugins: [react(), fileSystemMiddleware()],
  server: {
    port: 5174,
    host: true,
    open: true
  }
});